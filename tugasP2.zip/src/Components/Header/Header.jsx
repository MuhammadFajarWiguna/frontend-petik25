
function Header() {
  return (
    <nav>
      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Login</li>
      </ul>
      <button> Sign in</button>
    </nav>
  );
}

export default Header;